import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Navbar from '@/components/Navbar';
import ShortVideoHero from '@/components/ShortVideoHero';
import Features from '@/components/Features';
import VideoGallery from '@/components/VideoGallery';
import VideoSearch from '@/components/VideoSearch';
import Footer from '@/components/Footer';
import database from '@/services/database';
import { toast } from "sonner";

const ShortVideo = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [databaseInitialized, setDatabaseInitialized] = useState(false);

  useEffect(() => {
    // Initialize database connection
    const initDatabase = async () => {
      try {
        // This will initialize the database with mock data
        await database.getRecentVideos(1);
        setDatabaseInitialized(true);
        toast.success("Connected to AI video database");
      } catch (error) {
        console.error("Failed to initialize database:", error);
        toast.error("Failed to connect to database");
      }
    };
    
    initDatabase();
    
    // Smooth scroll behavior for anchor links
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchor = target.closest('a');
      
      if (anchor && anchor.hash && anchor.hash.startsWith('#')) {
        e.preventDefault();
        const element = document.querySelector(anchor.hash);
        if (element) {
          window.scrollTo({
            top: element.getBoundingClientRect().top + window.scrollY - 100,
            behavior: 'smooth'
          });
        }
      }
    };

    document.addEventListener('click', handleAnchorClick);
    
    // Set page title to reflect 4K AI video generation with database
    document.title = "Create 4K AI Short Videos | SQL Database Powered";
    
    return () => document.removeEventListener('click', handleAnchorClick);
  }, []);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setShowSearchResults(true);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Navbar />
        
        {!showSearchResults ? (
          <>
            <ShortVideoHero onSearch={handleSearch} />
            <VideoGallery />
          </>
        ) : (
          <VideoSearch query={searchQuery} onBackToHome={() => setShowSearchResults(false)} />
        )}
        
        <Features />
        <Footer />
        
        <div className="fixed bottom-8 right-8 z-40">
          <a
            href="#"
            className="flex items-center justify-center w-12 h-12 rounded-full bg-white shadow-elevated hover:shadow-lg transition-all duration-300"
            aria-label="Back to top"
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-5 w-5 text-gray-700" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M5 15l7-7 7 7" 
              />
            </svg>
          </a>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default ShortVideo;
