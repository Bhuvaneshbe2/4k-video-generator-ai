
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { motion } from 'framer-motion';
import { Sparkles, Download, Search } from 'lucide-react';
import { toast } from "sonner";
import { Link } from 'react-router-dom';
import database, { VideoRecord } from '@/services/database';
import DatabaseStatusBadge from './video-search/DatabaseStatusBadge';

const Hero = () => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generatedVideo, setGeneratedVideo] = useState<string | null>(null);
  const [isDatabaseConnected, setIsDatabaseConnected] = useState(false);
  const [searchMode, setSearchMode] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<VideoRecord[]>([]);

  useEffect(() => {
    const connectToDatabase = async () => {
      try {
        await database.getRecentVideos(1);
        setIsDatabaseConnected(true);
        toast.success("Connected to 4K AI video database");
      } catch (error) {
        console.error("Database connection error:", error);
        toast.error("Failed to connect to database");
      }
    };
    
    connectToDatabase();
  }, []);

  const handleGenerateVideo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    
    setIsGenerating(true);
    setGenerationProgress(0);
    setGeneratedVideo(null);
    
    // Simulate progress
    const interval = setInterval(() => {
      setGenerationProgress(prev => {
        const next = prev + Math.random() * 10;
        if (next >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setIsGenerating(false);
            // Simulate a generated video by showing a placeholder
            const videoSrc = "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";
            setGeneratedVideo(videoSrc);
            toast.success("Your 4K video has been successfully generated!");
          }, 1000);
          return 100;
        }
        return next;
      });
    }, 1000);
  };
  
  const handleNewVideo = () => {
    setGeneratedVideo(null);
    setPrompt('');
    setSearchResults([]);
    setSearchMode(false);
  };
  
  const handleDownload = () => {
    if (generatedVideo) {
      const link = document.createElement('a');
      link.href = generatedVideo;
      link.download = `AI-Video-${Date.now()}.mp4`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast.success("Download started!");
    }
  };

  const handleSearchModeToggle = () => {
    setSearchMode(prev => !prev);
    setSearchResults([]);
    setSearchTerm('');
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchTerm.trim()) return;
    
    setIsSearching(true);
    setSearchResults([]);
    
    toast.info(`Searching for "${searchTerm}" videos in database...`);
    
    try {
      const results = await database.searchVideos(searchTerm);
      
      setSearchResults(results);
      setIsSearching(false);
      
      if (results.length > 0) {
        toast.success(`Found ${results.length} videos related to "${searchTerm}"`);
      } else {
        toast.info(`No videos found for "${searchTerm}". Try generating a new one!`);
      }
    } catch (error) {
      console.error("Search error:", error);
      setIsSearching(false);
      toast.error("Error searching videos. Please try again.");
    }
  };

  const handleVideoClick = (video: VideoRecord) => {
    setPrompt(video.title);
    setGeneratedVideo(video.videoUrl);
    setSearchResults([]);
    toast.success(`Loaded video: ${video.title}`);
  };

  return (
    <section className="pt-32 pb-24 md:pt-40 md:pb-32 relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute top-0 left-0 right-0 h-[70%] bg-gradient-to-b from-blue-50 to-transparent -z-10"></div>
      
      {/* Floating elements */}
      <div className="absolute top-1/4 right-[10%] w-24 h-24 bg-blue-400/10 rounded-full blur-3xl animate-float"></div>
      <div className="absolute bottom-1/4 left-[10%] w-32 h-32 bg-purple-400/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }}></div>
      
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <div className="flex justify-between items-center mb-5">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight md:leading-tight lg:leading-tight text-balance">
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">
                {searchMode ? 'Search 4K Videos' : 'Create 4K Videos'}
              </span>
            </h1>
            
            {isDatabaseConnected && (
              <DatabaseStatusBadge isConnected={isDatabaseConnected} />
            )}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <p className="text-lg md:text-xl text-gray-600 mb-8 text-balance max-w-2xl mx-auto">
              {searchMode 
                ? 'Search our database for professional 4K videos on any topic. Find the perfect footage for your project.' 
                : 'Transform your ideas into professional 4K videos in minutes. Just type a prompt and our AI will generate a high-quality video ready for your project.'}
            </p>
          </motion.div>
          
          <div className="flex justify-center gap-4 mb-8">
            <Button
              className={`${searchMode 
                ? "border-blue-500 text-blue-600 hover:bg-blue-50" 
                : "bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white"} 
                py-2 px-6 rounded-lg`}
              variant={searchMode ? "outline" : "default"}
              onClick={() => {
                if (searchMode) handleSearchModeToggle();
              }}
            >
              Standard Video
            </Button>
            <Button
              className={`${!searchMode 
                ? "border-blue-500 text-blue-600 hover:bg-blue-50" 
                : "bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 text-white"} 
                py-2 px-6 rounded-lg`}
              variant={!searchMode ? "outline" : "default"}
              onClick={handleSearchModeToggle}
            >
              Search Video Database
            </Button>
            <Link to="/short-video">
              <Button
                variant="outline"
                className="border-blue-500 text-blue-600 hover:bg-blue-50 py-2 px-6 rounded-lg"
              >
                Short Video
              </Button>
            </Link>
          </div>
          
          {!generatedVideo ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative z-10"
            >
              {searchMode ? (
                // Search interface
                <form onSubmit={handleSearch} className="flex flex-col space-y-4">
                  <div className="relative">
                    <Input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="Search for videos (try 'mountain', 'city', 'elasticsearch'...)"
                      className="w-full pl-4 pr-12 py-6 text-base md:text-lg rounded-xl border border-gray-200 shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      disabled={isSearching}
                    />
                    <Search 
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" 
                      size={20}
                    />
                  </div>
                  
                  <Button
                    type="submit"
                    disabled={!searchTerm.trim() || isSearching}
                    className={`w-full md:w-auto md:min-w-[180px] mx-auto py-6 px-8 text-base md:text-lg font-medium rounded-xl transition-all duration-300 ${
                      isSearching 
                        ? 'bg-blue-400 cursor-not-allowed' 
                        : 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 shadow-lg hover:shadow-xl hover:shadow-blue-500/20'
                    }`}
                  >
                    {isSearching ? 'Searching...' : 'Search Database'}
                  </Button>
                </form>
              ) : (
                // Create interface
                <form onSubmit={handleGenerateVideo} className="flex flex-col space-y-4">
                  <div className="relative">
                    <Input
                      type="text"
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      placeholder="Describe your video: 'A cinematic drone shot over a mountain lake at sunset...'"
                      className="w-full pl-4 pr-12 py-6 text-base md:text-lg rounded-xl border border-gray-200 shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      disabled={isGenerating}
                    />
                    <Sparkles 
                      className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" 
                      size={20}
                    />
                  </div>
                  
                  <Button
                    type="submit"
                    disabled={!prompt.trim() || isGenerating}
                    className={`w-full md:w-auto md:min-w-[180px] mx-auto py-6 px-8 text-base md:text-lg font-medium rounded-xl transition-all duration-300 ${
                      isGenerating 
                        ? 'bg-blue-400 cursor-not-allowed' 
                        : 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 shadow-lg hover:shadow-xl hover:shadow-blue-500/20'
                    }`}
                  >
                    {isGenerating ? 'Generating...' : 'Generate Video'}
                  </Button>
                </form>
              )}
              
              {isGenerating && (
                <div className="mt-6 w-full">
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 transition-all duration-300 ease-in-out"
                      style={{ width: `${generationProgress}%` }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">
                    {generationProgress < 100 
                      ? `Creating your 4K video... ${Math.round(generationProgress)}%` 
                      : 'Video generated successfully!'}
                  </p>
                </div>
              )}
              
              {/* Search Results */}
              {searchMode && searchResults.length > 0 && (
                <div className="mt-8">
                  <h3 className="text-xl font-bold mb-4 text-left">Search Results ({searchResults.length})</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {searchResults.map((video) => (
                      <div 
                        key={video.id}
                        onClick={() => handleVideoClick(video)}
                        className="bg-white rounded-xl shadow-md overflow-hidden cursor-pointer hover:shadow-lg transition-shadow duration-300"
                      >
                        <div className="relative h-48">
                          <img 
                            src={video.thumbnailUrl} 
                            alt={video.title}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 px-2 py-1 rounded text-white text-xs">
                            {video.duration}
                          </div>
                        </div>
                        <div className="p-4">
                          <h4 className="text-md font-semibold mb-1 text-left">{video.title}</h4>
                          <p className="text-sm text-gray-600 line-clamp-2 text-left">{video.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="mt-8"
            >
              <div className="bg-white rounded-xl shadow-elevated p-4 mb-6">
                <h3 className="text-lg font-medium mb-3">Your 4K Video</h3>
                <div className="aspect-video rounded-lg overflow-hidden bg-gray-100">
                  <video 
                    src={generatedVideo} 
                    className="w-full h-full object-cover"
                    controls
                    autoPlay
                    muted
                  >
                    Your browser does not support the video tag.
                  </video>
                </div>
                <p className="text-sm text-gray-600 mt-3">
                  {prompt ? `Based on: "${prompt}"` : "Selected from search results"}
                </p>
                
                <div className="flex justify-center gap-4 mt-4">
                  <Button
                    onClick={handleNewVideo}
                    className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 shadow-lg hover:shadow-xl hover:shadow-blue-500/20 py-4 px-6 rounded-xl text-white font-medium"
                  >
                    {searchMode ? "New Search" : "Generate Another Video"}
                  </Button>
                  
                  <Button
                    onClick={handleDownload}
                    variant="outline"
                    className="border-blue-500 text-blue-600 hover:bg-blue-50 flex items-center gap-2 py-4 px-6 rounded-xl font-medium"
                  >
                    <Download size={18} />
                    Download Video
                  </Button>
                </div>
              </div>
            </motion.div>
          )}
          
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="mt-10 text-sm text-gray-500 flex flex-wrap justify-center gap-x-8 gap-y-3"
          >
            <div className="flex items-center">
              <svg className="w-5 h-5 mr-2 text-green-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
              </svg>
              <span>4K Resolution</span>
            </div>
            <div className="flex items-center">
              <svg className="w-5 h-5 mr-2 text-green-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
              </svg>
              <span>30 Minutes Max</span>
            </div>
            <div className="flex items-center">
              <svg className="w-5 h-5 mr-2 text-green-500" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd"></path>
              </svg>
              <span>Commercial License</span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
