
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Loader2 } from 'lucide-react';

interface SearchBarProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  onSearch: (e: React.FormEvent) => void;
  isSearching: boolean;
  isGenerating: boolean;
}

const SearchBar = ({ 
  searchTerm, 
  setSearchTerm, 
  onSearch, 
  isSearching, 
  isGenerating 
}: SearchBarProps) => {
  return (
    <form onSubmit={onSearch} className="mb-8">
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search for AI video ideas, try 'elasticsearch'..."
            className="pl-4 pr-12 py-6 text-base rounded-xl border border-gray-200 shadow-sm"
            disabled={isSearching || isGenerating}
          />
          <Search 
            className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400" 
            size={20}
          />
        </div>
        
        <Button
          type="submit"
          disabled={!searchTerm.trim() || isSearching || isGenerating}
          className="py-6 px-6 text-base font-medium rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
        >
          {isSearching ? (
            <>
              <Loader2 className="h-5 w-5 mr-2 animate-spin" />
              Searching...
            </>
          ) : "Search Database"}
        </Button>
      </div>
    </form>
  );
};

export default SearchBar;
