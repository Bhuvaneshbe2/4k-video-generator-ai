
import React from 'react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';
import { VideoRecord } from '@/services/database';

interface VideoGenerationProps {
  selectedResult: VideoRecord;
  generationProgress: number;
  onCancel: () => void;
}

const VideoGeneration = ({ selectedResult, generationProgress, onCancel }: VideoGenerationProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white rounded-xl shadow-elevated p-6 mb-8"
    >
      <h3 className="text-xl font-medium mb-4">Generating 4K AI Video</h3>
      
      <div className="flex flex-col md:flex-row gap-6 mb-6">
        <div className="md:w-1/3">
          <div className="aspect-video rounded-lg overflow-hidden bg-gray-100">
            <img 
              src={selectedResult.thumbnailUrl} 
              alt={selectedResult.title}
              className="w-full h-full object-cover"
            />
          </div>
        </div>
        
        <div className="md:w-2/3">
          <h4 className="text-lg font-medium mb-2">{selectedResult.title}</h4>
          <p className="text-gray-600 mb-4">{selectedResult.description}</p>
          
          <div className="mb-2 w-full">
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-purple-600 to-indigo-600 transition-all duration-300 ease-in-out"
                style={{ width: `${generationProgress}%` }}
              ></div>
            </div>
            <p className="text-sm text-gray-500 mt-2">
              {generationProgress < 100 
                ? `Generating 4K AI video... ${Math.round(generationProgress)}%` 
                : 'Video generated successfully!'}
            </p>
          </div>
        </div>
      </div>
      
      <Button
        onClick={onCancel}
        variant="outline"
        className="w-full md:w-auto border-purple-500 text-purple-600 hover:bg-purple-50"
      >
        Cancel Generation
      </Button>
    </motion.div>
  );
};

export default VideoGeneration;
