
import React from 'react';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';
import { motion } from 'framer-motion';
import { VideoRecord } from '@/services/database';

interface GeneratedVideoProps {
  generatedVideo: string;
  selectedResult: VideoRecord | null;
  onNewSearch: () => void;
  onDownload: () => void;
}

const GeneratedVideo = ({ 
  generatedVideo, 
  selectedResult, 
  onNewSearch, 
  onDownload 
}: GeneratedVideoProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="bg-white rounded-xl shadow-elevated p-6 mb-8"
    >
      <h3 className="text-xl font-medium mb-4">Your 4K AI-Generated Video</h3>
      <div className="aspect-[9/16] max-w-[350px] mx-auto rounded-lg overflow-hidden bg-gray-100 mb-4">
        <video 
          src={generatedVideo} 
          className="w-full h-full object-cover"
          controls
          autoPlay
          muted
        >
          Your browser does not support the video tag.
        </video>
      </div>
      
      <p className="text-sm text-gray-600 mb-6">
        Based on: "{selectedResult?.title}"
      </p>
      
      <div className="flex flex-wrap justify-center gap-4">
        <Button
          onClick={onNewSearch}
          className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 py-4 px-6 rounded-xl text-white font-medium"
        >
          New Database Search
        </Button>
        
        <Button
          onClick={onDownload}
          variant="outline"
          className="border-purple-500 text-purple-600 hover:bg-purple-50 flex items-center gap-2 py-4 px-6 rounded-xl font-medium"
        >
          <Download size={18} />
          Download 4K Video
        </Button>
      </div>
    </motion.div>
  );
};

export default GeneratedVideo;
