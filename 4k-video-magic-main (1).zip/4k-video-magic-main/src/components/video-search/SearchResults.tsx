
import React from 'react';
import { Loader2 } from 'lucide-react';
import VideoCard from './VideoCard';
import { VideoRecord } from '@/services/database';

interface SearchResultsProps {
  isSearching: boolean;
  results: VideoRecord[];
  query: string;
  onGenerateVideo: (result: VideoRecord) => void;
}

const SearchResults = ({ 
  isSearching, 
  results, 
  query, 
  onGenerateVideo 
}: SearchResultsProps) => {
  if (isSearching) {
    return (
      <div className="flex justify-center items-center py-20">
        <div className="flex flex-col items-center">
          <Loader2 className="h-10 w-10 text-purple-600 animate-spin mb-4" />
          <p className="text-lg text-gray-600">Searching database for videos...</p>
        </div>
      </div>
    );
  }
  
  if (results.length > 0) {
    // More flexible determination of prompt-related searches
    const isPromptSearch = query.toLowerCase().includes("prompt") || 
                          query.toLowerCase().includes("ai") || 
                          query.toLowerCase().includes("generate") ||
                          query.toLowerCase().includes("gpt") ||
                          query.toLowerCase().includes("meta") ||
                          query.toLowerCase().includes("google") ||
                          query.toLowerCase().includes("elasticsearch");
    
    // Get prompt-oriented results
    const promptResults = results.filter(r => r.isPromptOriented);
    
    // Get Google-specific results
    const googleResults = results.filter(r => r.source === "google" && !r.isPromptOriented);
    
    // Get OpenAI-specific results
    const openAiResults = results.filter(r => r.source === "openai" && !r.isPromptOriented);
    
    // Get other AI-specific results
    const otherAiResults = results.filter(r => r.source === "otherAi" && !r.isPromptOriented);
    
    // Get Elasticsearch-specific results
    const elasticsearchResults = results.filter(r => r.source === "elasticsearch" && !r.isPromptOriented);
    
    // Get database-specific results (from any database source)
    const databaseResults = results.filter(r => r.dbSource && !r.isPromptOriented && 
                                              r.source !== "google" && 
                                              r.source !== "openai" && 
                                              r.source !== "otherAi" &&
                                              r.source !== "elasticsearch");
    
    // Get remaining results
    const otherResults = results.filter(r => !r.isPromptOriented && !r.dbSource && !r.source);
    
    return (
      <div className="space-y-8">
        {/* Show prompt-oriented results if any exist or if this is a prompt-related search */}
        {promptResults.length > 0 && (
          <div>
            <h2 className="text-xl font-bold mb-4 text-purple-800">
              Prompt-Oriented AI Videos ({promptResults.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {promptResults.map((result) => (
                <VideoCard 
                  key={result.id} 
                  result={result} 
                  onGenerateVideo={onGenerateVideo}
                  isPromptOriented={true}
                />
              ))}
            </div>
          </div>
        )}
        
        {/* Show Elasticsearch results if any exist */}
        {elasticsearchResults.length > 0 && (
          <div>
            <h2 className="text-xl font-bold mb-4 text-amber-700">
              Elasticsearch Videos ({elasticsearchResults.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {elasticsearchResults.map((result) => (
                <VideoCard 
                  key={result.id} 
                  result={result} 
                  onGenerateVideo={onGenerateVideo}
                />
              ))}
            </div>
          </div>
        )}
        
        {/* Show Google results if any exist */}
        {googleResults.length > 0 && (
          <div>
            <h2 className="text-xl font-bold mb-4 text-blue-800">
              Google AI Videos ({googleResults.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {googleResults.map((result) => (
                <VideoCard 
                  key={result.id} 
                  result={result} 
                  onGenerateVideo={onGenerateVideo} 
                />
              ))}
            </div>
          </div>
        )}
        
        {/* Show OpenAI results if any exist */}
        {openAiResults.length > 0 && (
          <div>
            <h2 className="text-xl font-bold mb-4 text-purple-800">
              OpenAI Videos ({openAiResults.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {openAiResults.map((result) => (
                <VideoCard 
                  key={result.id} 
                  result={result} 
                  onGenerateVideo={onGenerateVideo} 
                />
              ))}
            </div>
          </div>
        )}
        
        {/* Show Other AI results if any exist */}
        {otherAiResults.length > 0 && (
          <div>
            <h2 className="text-xl font-bold mb-4 text-teal-800">
              Other AI Platform Videos ({otherAiResults.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {otherAiResults.map((result) => (
                <VideoCard 
                  key={result.id} 
                  result={result} 
                  onGenerateVideo={onGenerateVideo} 
                />
              ))}
            </div>
          </div>
        )}
        
        {/* Show database-specific results if any exist */}
        {databaseResults.length > 0 && (
          <div>
            <h2 className="text-xl font-bold mb-4 text-blue-800">
              Database Results ({databaseResults.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {databaseResults.map((result) => (
                <VideoCard 
                  key={result.id} 
                  result={result} 
                  onGenerateVideo={onGenerateVideo} 
                />
              ))}
            </div>
          </div>
        )}
        
        {/* Show other results */}
        {otherResults.length > 0 && (
          <div>
            <h2 className="text-xl font-bold mb-4 text-gray-800">
              {(promptResults.length > 0 || databaseResults.length > 0 || 
                googleResults.length > 0 || openAiResults.length > 0 || 
                otherAiResults.length > 0 || elasticsearchResults.length > 0) 
                ? 'Other Related Videos' 
                : 'Search Results'} 
              ({otherResults.length})
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {otherResults.map((result) => (
                <VideoCard 
                  key={result.id} 
                  result={result} 
                  onGenerateVideo={onGenerateVideo} 
                />
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }
  
  if (query) {
    return (
      <div className="text-center py-20">
        <p className="text-xl text-gray-600 mb-4">No videos found in database for "{query}"</p>
        <p className="text-gray-500">Try a different search term or browse our gallery</p>
      </div>
    );
  }
  
  return null;
};

export default SearchResults;
