
import React from 'react';
import { Database, Search, Cloud, MessageCircleCode, BotMessageSquare, Box, Server, Boxes, Table, Grid, Activity, BarChartHorizontal } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import database from '@/services/database';

interface DatabaseStatusBadgeProps {
  isConnected: boolean;
}

const DatabaseStatusBadge = ({ isConnected }: DatabaseStatusBadgeProps) => {
  const externalConnections = database.getExternalConnectionsStatus();
  const vectorConnections = database.getVectorConnectionsStatus();
  const googleDbConnections = database.getGoogleDatabasesStatus();

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-1 p-1.5 rounded-md ${isConnected ? 'bg-green-50' : 'bg-red-50'}`}>
              <Database className={`h-4 w-4 ${isConnected ? 'text-green-600' : 'text-red-600'}`} />
              <span className="text-xs font-medium">
                {isConnected ? 'SQL DB' : 'No DB'}
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{isConnected ? 'Local SQL database connected' : 'Database disconnected'}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      {/* External API connections */}
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-1 p-1.5 rounded-md ${externalConnections.google ? 'bg-blue-50' : 'bg-gray-100'}`}>
              <Cloud className={`h-4 w-4 ${externalConnections.google ? 'text-blue-600' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">
                Google
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{externalConnections.google ? 'Connected to Google video database' : 'Google video connection inactive'}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-1 p-1.5 rounded-md ${externalConnections.openai ? 'bg-purple-50' : 'bg-gray-100'}`}>
              <MessageCircleCode className={`h-4 w-4 ${externalConnections.openai ? 'text-purple-600' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">
                OpenAI
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{externalConnections.openai ? 'Connected to OpenAI video database' : 'OpenAI video connection inactive'}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-1 p-1.5 rounded-md ${externalConnections.otherAi ? 'bg-teal-50' : 'bg-gray-100'}`}>
              <BotMessageSquare className={`h-4 w-4 ${externalConnections.otherAi ? 'text-teal-600' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">
                Other AI
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{externalConnections.otherAi ? 'Connected to other AI database' : 'Other AI database connection inactive'}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      {/* Vector database connections */}
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-1 p-1.5 rounded-md ${vectorConnections.cosmosDB ? 'bg-indigo-50' : 'bg-gray-100'}`}>
              <Server className={`h-4 w-4 ${vectorConnections.cosmosDB ? 'text-indigo-600' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">
                Cosmos DB
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{vectorConnections.cosmosDB ? 'Connected to Cosmos DB vector database' : 'Cosmos DB connection inactive'}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-1 p-1.5 rounded-md ${vectorConnections.nuclia ? 'bg-amber-50' : 'bg-gray-100'}`}>
              <Box className={`h-4 w-4 ${vectorConnections.nuclia ? 'text-amber-600' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">
                Nuclia
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{vectorConnections.nuclia ? 'Connected to Nuclia knowledge box' : 'Nuclia connection inactive'}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-1 p-1.5 rounded-md ${vectorConnections.vectorDB ? 'bg-rose-50' : 'bg-gray-100'}`}>
              <Boxes className={`h-4 w-4 ${vectorConnections.vectorDB ? 'text-rose-600' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">
                Vector DB
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{vectorConnections.vectorDB ? 'Connected to vector database' : 'Vector database connection inactive'}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      {/* Google Database Connections */}
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-1 p-1.5 rounded-md ${googleDbConnections.bigtable ? 'bg-orange-50' : 'bg-gray-100'}`}>
              <Grid className={`h-4 w-4 ${googleDbConnections.bigtable ? 'text-orange-600' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">
                Bigtable
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{googleDbConnections.bigtable 
              ? 'Connected to Google Bigtable for large-scale data' 
              : 'Google Bigtable connection inactive'}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-1 p-1.5 rounded-md ${googleDbConnections.spanner ? 'bg-cyan-50' : 'bg-gray-100'}`}>
              <Activity className={`h-4 w-4 ${googleDbConnections.spanner ? 'text-cyan-600' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">
                Spanner
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{googleDbConnections.spanner 
              ? 'Connected to Google Spanner for global consistency' 
              : 'Google Spanner connection inactive'}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-1 p-1.5 rounded-md ${googleDbConnections.firebase ? 'bg-yellow-50' : 'bg-gray-100'}`}>
              <Activity className={`h-4 w-4 ${googleDbConnections.firebase ? 'text-yellow-600' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">
                Firebase
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{googleDbConnections.firebase 
              ? 'Connected to Firebase Realtime Database' 
              : 'Firebase Realtime Database connection inactive'}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-1 p-1.5 rounded-md ${googleDbConnections.memorystore ? 'bg-red-50' : 'bg-gray-100'}`}>
              <Database className={`h-4 w-4 ${googleDbConnections.memorystore ? 'text-red-600' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">
                Memory
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{googleDbConnections.memorystore 
              ? 'Connected to Google Memorystore for Redis/Memcached' 
              : 'Google Memorystore connection inactive'}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <div className={`flex items-center gap-1 p-1.5 rounded-md ${googleDbConnections.cloudSQL ? 'bg-green-50' : 'bg-gray-100'}`}>
              <Table className={`h-4 w-4 ${googleDbConnections.cloudSQL ? 'text-green-600' : 'text-gray-400'}`} />
              <span className="text-xs font-medium">
                Cloud SQL
              </span>
            </div>
          </TooltipTrigger>
          <TooltipContent>
            <p>{googleDbConnections.cloudSQL 
              ? 'Connected to Google Cloud SQL (MySQL/PostgreSQL/SQL Server)' 
              : 'Google Cloud SQL connection inactive'}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    </div>
  );
};

export default DatabaseStatusBadge;
