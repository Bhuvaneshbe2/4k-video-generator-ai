
import React from 'react';
import { Button } from '@/components/ui/button';
import { Video, Sparkles, BarChart, Grid, Activity, Database, Table } from 'lucide-react';
import { motion } from 'framer-motion';
import { VideoRecord } from '@/services/database';
import { Badge } from '@/components/ui/badge';

interface VideoCardProps {
  result: VideoRecord;
  onGenerateVideo: (result: VideoRecord) => void;
  isPromptOriented?: boolean;
}

const VideoCard = ({ result, onGenerateVideo, isPromptOriented }: VideoCardProps) => {
  // Function to determine icon for Google database sources
  const getDbSourceIcon = () => {
    if (!result.dbSource) return null;
    
    switch(result.dbSource) {
      case 'bigtable':
        return <Grid className="h-3 w-3 mr-1" />;
      case 'spanner':
        return <Activity className="h-3 w-3 mr-1" />;
      case 'firebase':
        return <Activity className="h-3 w-3 mr-1" />; 
      case 'memorystore':
        return <Database className="h-3 w-3 mr-1" />;
      case 'cloudSQL':
        return <Table className="h-3 w-3 mr-1" />;
      default:
        return null;
    }
  };

  // Function to determine badge color for Google database sources
  const getDbSourceColor = () => {
    if (!result.dbSource) return '';
    
    switch(result.dbSource) {
      case 'bigtable':
        return 'border-orange-300 text-orange-700 bg-orange-50';
      case 'spanner':
        return 'border-cyan-300 text-cyan-700 bg-cyan-50';
      case 'firebase':
        return 'border-yellow-300 text-yellow-700 bg-yellow-50';
      case 'memorystore':
        return 'border-red-300 text-red-700 bg-red-50';
      case 'cloudSQL':
        return 'border-green-300 text-green-700 bg-green-50';
      default:
        return '';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={`bg-white rounded-xl shadow-sm hover:shadow-elevated transition-all duration-300 overflow-hidden ${
        result.isPromptOriented ? 'border border-purple-200' : result.vectorMatch ? 'border border-indigo-200' : ''
      }`}
    >
      <div className="aspect-video relative">
        <img 
          src={result.thumbnailUrl} 
          alt={result.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
          {result.duration}
        </div>
        
        {result.isPromptOriented && (
          <div className="absolute top-2 left-2">
            <Badge variant="secondary" className="bg-purple-100 text-purple-800 border-purple-300">
              <Sparkles className="h-3 w-3 mr-1" />
              Prompt-Engineered
            </Badge>
          </div>
        )}

        {result.vectorMatch && (
          <div className="absolute top-2 left-2">
            {!result.isPromptOriented && (
              <Badge variant="secondary" className="bg-indigo-100 text-indigo-800 border-indigo-300">
                <BarChart className="h-3 w-3 mr-1" />
                {`Match: ${Math.round(result.vectorMatch * 100)}%`}
              </Badge>
            )}
          </div>
        )}
        
        {result.source && (
          <div className="absolute bottom-2 left-2 flex gap-1 flex-wrap">
            <Badge variant="outline" className={`bg-white/90 text-xs ${
              result.source === 'cosmosDB' ? 'border-indigo-300 text-indigo-700' :
              result.source === 'nuclia' ? 'border-amber-300 text-amber-700' :
              result.source === 'vectorDB' ? 'border-rose-300 text-rose-700' :
              result.source === 'google' ? 'border-blue-300 text-blue-700' : 
              result.source === 'openai' ? 'border-purple-300 text-purple-700' : 
              result.source === 'otherAi' ? 'border-teal-300 text-teal-700' : 'border-gray-300'
            }`}>
              {result.source === 'google' ? 'Google' : 
               result.source === 'openai' ? 'OpenAI' : 
               result.source === 'otherAi' ? 'Other AI' :
               result.source === 'cosmosDB' ? 'Cosmos DB' :
               result.source === 'nuclia' ? 'Nuclia' :
               result.source === 'vectorDB' ? 'Vector DB' : 'Local'}
            </Badge>
            
            {/* Show specific Google database source badge if available */}
            {result.dbSource && (
              <Badge variant="outline" className={`bg-white/90 text-xs ${getDbSourceColor()}`}>
                {getDbSourceIcon()}
                {result.dbSource === 'bigtable' ? 'Bigtable' :
                 result.dbSource === 'spanner' ? 'Spanner' :
                 result.dbSource === 'firebase' ? 'Firebase' :
                 result.dbSource === 'memorystore' ? 'Memorystore' :
                 result.dbSource === 'cloudSQL' ? 'Cloud SQL' : result.dbSource}
              </Badge>
            )}
          </div>
        )}
      </div>
      
      <div className="p-4">
        <h3 className="font-medium text-lg mb-2 line-clamp-1">{result.title}</h3>
        <p className="text-sm text-gray-600 mb-4 line-clamp-2">{result.description}</p>
        
        <Button
          onClick={() => onGenerateVideo(result)}
          className={`w-full py-2 ${
            result.isPromptOriented 
              ? 'bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800' 
              : result.vectorMatch
              ? 'bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700'
              : result.dbSource
              ? 'bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700'
              : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700'
          }`}
        >
          {result.isPromptOriented ? (
            <>
              <Sparkles className="h-4 w-4 mr-2" />
              Generate with Prompt
            </>
          ) : result.vectorMatch ? (
            <>
              <BarChart className="h-4 w-4 mr-2" />
              Generate Semantic Match
            </>
          ) : result.dbSource ? (
            <>
              {getDbSourceIcon() || <Video className="h-4 w-4 mr-2" />}
              Generate from {result.dbSource}
            </>
          ) : (
            <>
              <Video className="h-4 w-4 mr-2" />
              Generate 4K 30s Video
            </>
          )}
        </Button>
      </div>
    </motion.div>
  );
};

export default VideoCard;
