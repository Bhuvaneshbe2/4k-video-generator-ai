
import React from 'react';
import { motion } from 'framer-motion';

interface Logo4KProps {
  size?: number;
  className?: string;
}

const Logo4K: React.FC<Logo4KProps> = ({ size = 40, className = '' }) => {
  return (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.3 }}
      className={`relative flex items-center justify-center ${className}`}
      style={{ width: size, height: size }}
    >
      <div className="absolute inset-0 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600" />
      <div className="absolute inset-1 rounded-full bg-yellow-500" />
      <div className="absolute inset-1.5 rounded-full bg-gradient-to-br from-yellow-400 via-amber-500 to-yellow-600 flex items-center justify-center shadow-inner">
        <span className="text-white font-bold" style={{ fontSize: size * 0.4, lineHeight: 1 }}>
          4K
        </span>
      </div>
    </motion.div>
  );
};

export default Logo4K;
