
import React from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Sparkles, Video } from 'lucide-react';

const steps = [
  {
    icon: <MessageSquare className="h-8 w-8 text-white" />,
    title: 'Describe Your Vision',
    description: 'Enter a detailed text prompt describing the video you want to create. Be as specific as you like about scenes, style, and mood.',
    color: 'from-blue-500 to-blue-600'
  },
  {
    icon: <Sparkles className="h-8 w-8 text-white" />,
    title: 'AI Generates Content',
    description: 'Our advanced AI analyzes your prompt and begins generating a high-quality 4K video, handling all aspects of production automatically.',
    color: 'from-indigo-500 to-indigo-600'
  },
  {
    icon: <Video className="h-8 w-8 text-white" />,
    title: 'Download & Use',
    description: 'Within 30 minutes, your professionally rendered video is ready to download and use in your projects, presentations, or social media.',
    color: 'from-purple-500 to-purple-600'
  }
];

const HowItWorks = () => {
  return (
    <section id="how-it-works" className="py-20 md:py-32">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How It Works</h2>
            <p className="text-xl text-gray-600 text-balance">
              Creating stunning 4K videos has never been easier. Just three simple steps from idea to finished product.
            </p>
          </motion.div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {steps.map((step, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="flex flex-col items-center text-center"
            >
              <div className={`flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-r ${step.color} mb-6 shadow-lg`}>
                {step.icon}
              </div>
              <div className="relative mb-12 md:mb-0">
                <h3 className="text-2xl font-semibold mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
                
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-8 left-full w-full h-[2px] bg-gradient-to-r from-gray-200 to-gray-300 transform translate-x-4">
                    <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-3 h-3 rounded-full bg-gray-300"></div>
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="mt-20 p-8 md:p-12 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl max-w-4xl mx-auto text-center"
        >
          <h3 className="text-2xl md:text-3xl font-semibold mb-4">Ready to transform your ideas into stunning videos?</h3>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Join thousands of creators, marketers, and businesses who are revolutionizing their video production with AI.
          </p>
          <button className="px-8 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-medium rounded-xl shadow-lg hover:shadow-xl hover:shadow-blue-500/20 transition-all duration-300">
            Start Creating Now
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default HowItWorks;
