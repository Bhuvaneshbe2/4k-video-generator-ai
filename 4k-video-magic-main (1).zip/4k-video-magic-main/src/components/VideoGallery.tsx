
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Play, Download } from 'lucide-react';

// Sample video data
const videos = [
  {
    id: 1,
    title: 'Mountain Landscape Timelapse',
    prompt: 'Cinematic 4K timelapse of mountains with changing weather conditions from day to night',
    thumbnail: 'https://images.unsplash.com/photo-1519681393784-d120267933ba',
    duration: '0:45'
  },
  {
    id: 2,
    title: 'Ocean Waves at Sunset',
    prompt: 'Aerial view of ocean waves crashing on a beach during golden hour sunset with warm tones',
    thumbnail: 'https://images.unsplash.com/photo-1590523277543-a94d2e4eb00b',
    duration: '1:20'
  },
  {
    id: 3,
    title: 'Urban City Nightlife',
    prompt: 'Busy city streets at night with neon lights, traffic, and people walking',
    thumbnail: 'https://images.unsplash.com/photo-1541535650810-10d26f5c2ab3',
    duration: '2:10'
  },
  {
    id: 4,
    title: 'Forest Wildlife',
    prompt: 'Detailed nature documentary style footage of wildlife in a dense forest with sunbeams',
    thumbnail: 'https://images.unsplash.com/photo-1473773508845-188df298d2d1',
    duration: '0:58'
  },
  {
    id: 5,
    title: 'Abstract Particles Flow',
    prompt: 'Colorful abstract particle flow animation with smooth movements and light effects',
    thumbnail: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809',
    duration: '1:35'
  },
  {
    id: 6,
    title: 'Culinary Close-up',
    prompt: 'Professional food cinematography with close-up shots of gourmet dishes being prepared',
    thumbnail: 'https://images.unsplash.com/photo-1495521821757-a1efb6729352',
    duration: '2:25'
  }
];

interface VideoCardProps {
  video: typeof videos[0];
  onClick: () => void;
}

const VideoCard = ({ video, onClick }: VideoCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      viewport={{ once: true }}
      className="group cursor-pointer relative rounded-xl overflow-hidden shadow-card hover:shadow-elevated transition-all duration-300"
      onClick={onClick}
    >
      <div className="aspect-video w-full bg-gray-200 relative overflow-hidden">
        <img 
          src={`${video.thumbnail}?auto=format&fit=crop&w=800&q=80`} 
          alt={video.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-16 h-16 rounded-full bg-white/90 flex items-center justify-center shadow-lg transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
            <Play className="h-6 w-6 text-blue-600 ml-1" />
          </div>
        </div>
        
        <div className="absolute bottom-3 right-3 bg-black/70 text-white text-sm px-2 py-1 rounded-md">
          {video.duration}
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-1 truncate">{video.title}</h3>
        <p className="text-sm text-gray-600 line-clamp-2">{video.prompt}</p>
      </div>
    </motion.div>
  );
};

interface VideoModalProps {
  video: typeof videos[0] | null;
  onClose: () => void;
}

const VideoModal = ({ video, onClose }: VideoModalProps) => {
  if (!video) return null;
  
  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
        transition={{ duration: 0.3 }}
        className="bg-white rounded-xl overflow-hidden max-w-4xl w-full max-h-[90vh] shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="aspect-video w-full bg-gray-900 relative">
          {/* This would be a real video in production */}
          <img 
            src={`${video.thumbnail}?auto=format&fit=crop&w=1200&q=90`} 
            alt={video.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-20 h-20 rounded-full bg-white/90 flex items-center justify-center shadow-lg">
              <Play className="h-8 w-8 text-blue-600 ml-1" />
            </div>
          </div>
        </div>
        
        <div className="p-6">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-2xl font-semibold mb-2">{video.title}</h3>
              <p className="text-gray-600 mb-4">{video.prompt}</p>
            </div>
            <button 
              className="flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
            >
              <Download className="h-4 w-4 mr-2" />
              Download
            </button>
          </div>
          
          <div className="mt-4 pt-4 border-t border-gray-200">
            <h4 className="font-medium mb-2">Video Details</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Resolution:</span> 4K (3840 x 2160)
              </div>
              <div>
                <span className="text-gray-500">Duration:</span> {video.duration}
              </div>
              <div>
                <span className="text-gray-500">Format:</span> MP4
              </div>
              <div>
                <span className="text-gray-500">Frame Rate:</span> 60 FPS
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

const VideoGallery = () => {
  const [selectedVideo, setSelectedVideo] = useState<typeof videos[0] | null>(null);
  
  return (
    <section id="gallery" className="py-20 md:py-32 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Inspiration Gallery
            </h2>
            <p className="text-xl text-gray-600 text-balance">
              Browse examples of stunning AI-generated videos created with just a text prompt.
            </p>
          </motion.div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {videos.map((video) => (
            <VideoCard 
              key={video.id} 
              video={video} 
              onClick={() => setSelectedVideo(video)}
            />
          ))}
        </div>
        
        {selectedVideo && (
          <VideoModal video={selectedVideo} onClose={() => setSelectedVideo(null)} />
        )}
      </div>
    </section>
  );
};

export default VideoGallery;
