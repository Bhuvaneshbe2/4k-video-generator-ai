
import React, { useState, useEffect } from 'react';
import { toast } from "sonner";
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import database, { VideoRecord } from '@/services/database';
import SearchBar from './video-search/SearchBar';
import VideoGeneration from './video-search/VideoGeneration';
import GeneratedVideo from './video-search/GeneratedVideo';
import SearchResults from './video-search/SearchResults';
import VideoFeatureList from './video-search/VideoFeatureList';
import DatabaseStatusBadge from './video-search/DatabaseStatusBadge';

interface VideoSearchProps {
  query: string;
  onBackToHome: () => void;
}

const VideoSearch = ({ query, onBackToHome }: VideoSearchProps) => {
  const [searchTerm, setSearchTerm] = useState(query);
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState<VideoRecord[]>([]);
  const [selectedResult, setSelectedResult] = useState<VideoRecord | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [generatedVideo, setGeneratedVideo] = useState<string | null>(null);
  const [isDatabaseConnected, setIsDatabaseConnected] = useState(false);

  useEffect(() => {
    const connectToDatabase = async () => {
      try {
        await database.getRecentVideos(1);
        setIsDatabaseConnected(true);
        toast.success("Connected to AI video database");
      } catch (error) {
        console.error("Database connection error:", error);
        toast.error("Failed to connect to database");
      }
    };
    
    connectToDatabase();
    
    if (query) {
      performSearch(query);
    }
  }, [query]);

  const performSearch = async (term: string) => {
    if (!term.trim()) return;
    
    setIsSearching(true);
    setResults([]);
    
    toast.info(`Searching for "${term}" videos in database...`);
    
    try {
      const searchResults = await database.searchVideos(term);
      
      setResults(searchResults);
      setIsSearching(false);
      
      if (searchResults.length > 0) {
        toast.success(`Found ${searchResults.length} videos related to "${term}"`);
      } else {
        toast.info(`No videos found for "${term}". You can generate a new one!`);
      }
    } catch (error) {
      console.error("Search error:", error);
      setIsSearching(false);
      toast.error("Error searching videos. Please try again.");
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch(searchTerm);
  };

  const handleGenerateVideo = async (result: VideoRecord) => {
    setSelectedResult(result);
    setIsGenerating(true);
    setGenerationProgress(0);
    setGeneratedVideo(null);
    
    toast.info(`Connecting to AI to create "${result.title}" video...`);
    
    const interval = setInterval(() => {
      setGenerationProgress(prev => {
        const next = prev + Math.random() * 8;
        if (next >= 100) {
          clearInterval(interval);
          setTimeout(async () => {
            setIsGenerating(false);
            setGeneratedVideo(result.videoUrl);
            
            try {
              await database.saveGeneratedVideo({
                title: `Generated: ${result.title}`,
                description: `AI-generated version of ${result.title}`,
                keywords: [...result.keywords, 'ai-generated'],
                thumbnailUrl: result.thumbnailUrl,
                videoUrl: result.videoUrl,
                duration: "0:30"
              });
              
              toast.success("Your 30-second 4K AI video has been successfully generated and saved to database!");
            } catch (error) {
              console.error("Error saving video:", error);
              toast.error("Error saving video to database");
            }
          }, 1000);
          return 100;
        }
        return next;
      });
    }, 1200);
  };
  
  const handleDownload = () => {
    if (generatedVideo) {
      const link = document.createElement('a');
      link.href = generatedVideo;
      link.download = `AI-${searchTerm}-Video-${Date.now()}.mp4`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast.success("Download started! This 4K AI-generated video is ready for use.");
    }
  };
  
  const handleNewSearch = () => {
    setGeneratedVideo(null);
    setSelectedResult(null);
  };

  return (
    <section className="pt-32 pb-24 md:pt-40 md:pb-32 relative overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-[70%] bg-gradient-to-b from-purple-50 to-transparent -z-10"></div>
      
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8 flex items-center justify-between">
            <div className="flex items-center">
              <Button
                variant="ghost"
                className="mr-3"
                onClick={onBackToHome}
              >
                <ArrowLeft className="h-5 w-5 mr-1" />
                Back to Home
              </Button>
              
              <h1 className="text-2xl md:text-3xl font-bold">
                {generatedVideo 
                  ? "Your Generated 4K AI Video" 
                  : selectedResult 
                    ? `Generating: ${selectedResult.title}` 
                    : `Search Results for "${query}"`}
              </h1>
            </div>
            
            <DatabaseStatusBadge isConnected={isDatabaseConnected} />
          </div>
          
          <SearchBar 
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            onSearch={handleSearch}
            isSearching={isSearching}
            isGenerating={isGenerating}
          />
          
          {generatedVideo && selectedResult ? (
            <GeneratedVideo 
              generatedVideo={generatedVideo}
              selectedResult={selectedResult}
              onNewSearch={handleNewSearch}
              onDownload={handleDownload}
            />
          ) : selectedResult ? (
            <VideoGeneration 
              selectedResult={selectedResult}
              generationProgress={generationProgress}
              onCancel={handleNewSearch}
            />
          ) : (
            <SearchResults 
              isSearching={isSearching}
              results={results}
              query={query}
              onGenerateVideo={handleGenerateVideo}
            />
          )}
          
          <VideoFeatureList />
        </div>
      </div>
    </section>
  );
};

export default VideoSearch;
