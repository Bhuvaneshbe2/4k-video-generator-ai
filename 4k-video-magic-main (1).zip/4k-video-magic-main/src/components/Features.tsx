
import React from 'react';
import { motion } from 'framer-motion';
import { Wand2, Clock, Film, Download, Palette, Scissors } from 'lucide-react';

const features = [
  {
    icon: <Wand2 className="h-8 w-8 text-blue-500" />,
    title: 'Simple Text Prompts',
    description: 'Describe your vision in natural language, and our AI brings it to life with stunning visuals.'
  },
  {
    icon: <Clock className="h-8 w-8 text-blue-500" />,
    title: 'Rapid Generation',
    description: 'Create professional 4K videos in as little as 30 minutes, saving days of traditional production time.'
  },
  {
    icon: <Film className="h-8 w-8 text-blue-500" />,
    title: '4K Ultra HD Quality',
    description: 'Every video rendered in crystal-clear 4K resolution, perfect for professional presentations and content.'
  },
  {
    icon: <Download className="h-8 w-8 text-blue-500" />,
    title: 'Instant Downloads',
    description: 'Download your videos immediately after generation in multiple formats for any platform.'
  },
  {
    icon: <Palette className="h-8 w-8 text-blue-500" />,
    title: 'Style Controls',
    description: 'Fine-tune the visual aesthetic of your videos with customizable style parameters.'
  },
  {
    icon: <Scissors className="h-8 w-8 text-blue-500" />,
    title: 'No Editing Required',
    description: 'Videos come ready to use with perfect pacing, transitions, and visual composition.'
  }
];

const FeatureCard = ({ feature, index }: { feature: typeof features[0], index: number }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      className="flex flex-col p-6 bg-white rounded-2xl shadow-card hover:shadow-elevated transition-all duration-300 border border-gray-100"
    >
      <div className="p-3 mb-5 rounded-xl bg-blue-50 w-fit">
        {feature.icon}
      </div>
      <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
      <p className="text-gray-600">{feature.description}</p>
    </motion.div>
  );
};

const Features = () => {
  return (
    <section id="features" className="py-20 md:py-32 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Advanced AI Features, 
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600"> Simple Interface</span>
            </h2>
            <p className="text-xl text-gray-600 text-balance">
              Our cutting-edge technology makes video creation effortless while delivering professional results.
            </p>
          </motion.div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard key={index} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
