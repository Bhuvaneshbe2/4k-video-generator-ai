
import React from 'react';
import { motion } from 'framer-motion';
import { Check } from 'lucide-react';
import { Button } from '@/components/ui/button';

const plans = [
  {
    name: 'Basic',
    price: '$19',
    period: 'per month',
    description: 'Perfect for occasional creators and personal projects.',
    features: [
      'Up to 5 videos per month',
      '4K resolution',
      'Max 5 minutes per video',
      'Standard generation speed',
      'Basic editing controls',
      'Commercial use allowed'
    ],
    cta: 'Get Started',
    highlight: false
  },
  {
    name: 'Professional',
    price: '$49',
    period: 'per month',
    description: 'Ideal for content creators and small businesses.',
    features: [
      'Up to 20 videos per month',
      '4K resolution',
      'Max 15 minutes per video',
      'Priority generation speed',
      'Advanced editing tools',
      'Stock music library access',
      'Email support'
    ],
    cta: 'Start Free Trial',
    highlight: true
  },
  {
    name: 'Studio',
    price: '$99',
    period: 'per month',
    description: 'For professionals and agencies with high-volume needs.',
    features: [
      'Up to 50 videos per month',
      '4K resolution',
      'Max 30 minutes per video',
      'Fastest generation speed',
      'Full editing suite',
      'Custom style tuning',
      'Priority support',
      'API access'
    ],
    cta: 'Contact Sales',
    highlight: false
  }
];

const Pricing = () => {
  return (
    <section id="pricing" className="py-20 md:py-32">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Choose Your Plan
            </h2>
            <p className="text-xl text-gray-600 text-balance">
              Select the perfect plan for your video creation needs. All plans include 4K quality and commercial usage rights.
            </p>
          </motion.div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className={`relative flex flex-col p-6 md:p-8 rounded-2xl shadow-card transition-all duration-300 hover:shadow-elevated ${
                plan.highlight
                  ? 'border-2 border-blue-500 bg-white'
                  : 'border border-gray-200 bg-white'
              }`}
            >
              {plan.highlight && (
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-blue-600 text-white text-xs px-3 py-1 rounded-full font-medium">
                  Most Popular
                </div>
              )}
              
              <div className="mb-6">
                <h3 className="text-2xl font-semibold mb-2">{plan.name}</h3>
                <p className="text-gray-600 mb-4 min-h-[48px]">{plan.description}</p>
                <div className="flex items-baseline">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-gray-600 ml-2">{plan.period}</span>
                </div>
              </div>
              
              <div className="mb-8 flex-grow">
                <ul className="space-y-3">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <Check className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <Button
                className={`w-full py-6 font-medium rounded-xl ${
                  plan.highlight
                    ? 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 shadow-lg hover:shadow-blue-500/20'
                    : 'bg-gray-800 hover:bg-gray-900'
                }`}
              >
                {plan.cta}
              </Button>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <p className="text-gray-600">
            Need a custom plan for your enterprise? <a href="#" className="text-blue-600 font-medium">Contact our sales team</a>
          </p>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
