import { toast } from "sonner";

// Database configuration - can be extended to support different sources
const DB_CONFIG = {
  host: "localhost",
  port: 3306,
  user: "aiuser",
  password: "password", // In a real app, use environment variables
  database: "ai_videos_db",
  // External API connections
  externalApis: {
    google: {
      enabled: true,
      endpoint: "https://api.example.com/google-videos", // Placeholder URL
    },
    openai: {
      enabled: true,
      endpoint: "https://api.example.com/ai-videos", // Placeholder URL
    },
    otherAi: {
      enabled: true,
      endpoint: "https://api.example.com/other-ai-videos", // Placeholder URL
    }
  },
  // Vector database connections
  vectorDatabases: {
    cosmosDB: {
      enabled: true,
      endpoint: "https://cosmos-example.azure.com",
      containerName: "videoVectors"
    },
    nuclia: {
      enabled: true,
      endpoint: "https://api.nuclia.cloud",
      knowledgeBoxId: "kb123456"
    },
    vectorDB: {
      enabled: true,
      endpoint: "https://api.vectordb.example",
      dimension: 1536 // Vector dimension for embeddings
    }
  },
  // Google database connections
  googleDatabases: {
    bigtable: {
      enabled: true,
      endpoint: "https://bigtable.googleapis.com",
      projectId: "ai-video-project",
      instanceId: "video-data-instance"
    },
    spanner: {
      enabled: true,
      endpoint: "https://spanner.googleapis.com",
      projectId: "ai-video-project",
      instanceId: "video-spanner-instance",
      databaseId: "video-catalog"
    },
    firebase: {
      enabled: true, 
      databaseURL: "https://ai-video-app.firebaseio.com"
    },
    memorystore: {
      enabled: true,
      endpoint: "redis://memorystore.googleapis.com:6379"
    },
    cloudSQL: {
      enabled: true,
      instanceConnectionName: "ai-video-project:us-central1:video-postgres",
      databaseType: "PostgreSQL" // or "MySQL" or "SQL Server"
    }
  }
};

// Mock implementation since we can't connect to a real SQL database in the browser
// In a real application, this would use a backend service with proper SQL connection
export class DatabaseService {
  private static instance: DatabaseService;
  private videos: VideoRecord[] = [];
  private isInitialized = false;
  private externalConnections: Record<string, boolean> = {
    google: false,
    openai: false,
    otherAi: false
  };
  private vectorConnections: Record<string, boolean> = {
    cosmosDB: false,
    nuclia: false,
    vectorDB: false
  };
  private googleDbConnections: Record<string, boolean> = {
    bigtable: false,
    spanner: false,
    firebase: false,
    memorystore: false,
    cloudSQL: false
  };

  // Singleton pattern
  public static getInstance(): DatabaseService {
    if (!DatabaseService.instance) {
      DatabaseService.instance = new DatabaseService();
    }
    return DatabaseService.instance;
  }

  constructor() {
    this.initializeDatabase();
  }

  private async initializeDatabase() {
    console.log("Initializing database connection...");
    
    // Simulate database initialization
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock data for demonstration purposes
    this.videos = [
      {
        id: "v1",
        title: "Mountain Sunrise Timelapse",
        description: "Beautiful 4K timelapse of sunrise over mountain ranges",
        keywords: ["mountain", "sunrise", "nature", "timelapse"],
        thumbnailUrl: "https://source.unsplash.com/random/800x450?mountain,sunrise",
        videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        duration: "0:30",
        createdAt: new Date().toISOString()
      },
      {
        id: "v2",
        title: "Ocean Waves Aerial View",
        description: "Stunning 4K aerial footage of ocean waves crashing on shore",
        keywords: ["ocean", "waves", "aerial", "nature"],
        thumbnailUrl: "https://source.unsplash.com/random/800x450?ocean,waves",
        videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
        duration: "0:30",
        createdAt: new Date().toISOString()
      },
      {
        id: "v3",
        title: "Urban City Nightlife",
        description: "Vibrant 4K footage of city streets and nightlife",
        keywords: ["city", "urban", "night", "street"],
        thumbnailUrl: "https://source.unsplash.com/random/800x450?city,night",
        videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
        duration: "0:30",
        createdAt: new Date().toISOString()
      },
      {
        id: "v4",
        title: "Wildlife Documentary Clip",
        description: "4K wildlife footage featuring exotic animals in their habitat",
        keywords: ["wildlife", "animals", "nature", "documentary"],
        thumbnailUrl: "https://source.unsplash.com/random/800x450?wildlife,animals",
        videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
        duration: "0:30",
        createdAt: new Date().toISOString()
      },
      {
        id: "v5",
        title: "Prompt-Oriented AI Video Tutorial",
        description: "Learn how to create amazing videos using prompt engineering techniques with AI",
        keywords: ["prompt", "ai-video", "tutorial", "prompt-engineering"],
        thumbnailUrl: "https://source.unsplash.com/random/800x450?ai,tutorial",
        videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
        duration: "1:45",
        createdAt: new Date().toISOString(),
        isPromptOriented: true
      },
      {
        id: "v6",
        title: "Advanced Prompt Engineering for Video Generation",
        description: "Master the art of crafting perfect prompts for AI video generation systems",
        keywords: ["prompt-engineering", "advanced", "ai-video", "generation"],
        thumbnailUrl: "https://source.unsplash.com/random/800x450?engineering,video",
        videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4",
        duration: "2:15",
        createdAt: new Date().toISOString(),
        isPromptOriented: true
      }
    ];
    
    // Simulate external API connections
    await this.connectToExternalSources();
    
    // Simulate vector database connections
    await this.connectToVectorDatabases();
    
    // Simulate Google database connections
    await this.connectToGoogleDatabases();
    
    this.isInitialized = true;
    console.log("Database initialized with mock data and all connections");
  }

  private async connectToExternalSources() {
    console.log("Connecting to external data sources...");
    
    // Simulate connecting to Google
    if (DB_CONFIG.externalApis.google.enabled) {
      await new Promise(resolve => setTimeout(resolve, 800));
      this.externalConnections.google = true;
      console.log("Connected to Google video database");
    }
    
    // Simulate connecting to OpenAI
    if (DB_CONFIG.externalApis.openai.enabled) {
      await new Promise(resolve => setTimeout(resolve, 600));
      this.externalConnections.openai = true;
      console.log("Connected to OpenAI video database");
    }
    
    // Simulate connecting to Other AI service
    if (DB_CONFIG.externalApis.otherAi.enabled) {
      await new Promise(resolve => setTimeout(resolve, 700));
      this.externalConnections.otherAi = true;
      console.log("Connected to Other AI video database");
    }
  }

  private async connectToVectorDatabases() {
    console.log("Connecting to vector databases...");
    
    // Simulate connecting to Cosmos DB
    if (DB_CONFIG.vectorDatabases.cosmosDB.enabled) {
      await new Promise(resolve => setTimeout(resolve, 850));
      this.vectorConnections.cosmosDB = true;
      console.log("Connected to Cosmos DB vector database");
    }
    
    // Simulate connecting to Nuclia
    if (DB_CONFIG.vectorDatabases.nuclia.enabled) {
      await new Promise(resolve => setTimeout(resolve, 750));
      this.vectorConnections.nuclia = true;
      console.log("Connected to Nuclia knowledge box");
    }
    
    // Simulate connecting to Vector DB
    if (DB_CONFIG.vectorDatabases.vectorDB.enabled) {
      await new Promise(resolve => setTimeout(resolve, 900));
      this.vectorConnections.vectorDB = true;
      console.log("Connected to vector database");
    }
  }

  private async connectToGoogleDatabases() {
    console.log("Connecting to Google databases...");
    
    // Simulate connecting to Bigtable
    if (DB_CONFIG.googleDatabases.bigtable.enabled) {
      await new Promise(resolve => setTimeout(resolve, 700));
      this.googleDbConnections.bigtable = true;
      console.log("Connected to Google Bigtable database");
    }
    
    // Simulate connecting to Spanner
    if (DB_CONFIG.googleDatabases.spanner.enabled) {
      await new Promise(resolve => setTimeout(resolve, 750));
      this.googleDbConnections.spanner = true;
      console.log("Connected to Google Spanner database");
    }
    
    // Simulate connecting to Firebase
    if (DB_CONFIG.googleDatabases.firebase.enabled) {
      await new Promise(resolve => setTimeout(resolve, 600));
      this.googleDbConnections.firebase = true;
      console.log("Connected to Firebase Realtime Database");
    }
    
    // Simulate connecting to Memorystore
    if (DB_CONFIG.googleDatabases.memorystore.enabled) {
      await new Promise(resolve => setTimeout(resolve, 550));
      this.googleDbConnections.memorystore = true;
      console.log("Connected to Google Memorystore");
    }
    
    // Simulate connecting to Cloud SQL
    if (DB_CONFIG.googleDatabases.cloudSQL.enabled) {
      await new Promise(resolve => setTimeout(resolve, 800));
      this.googleDbConnections.cloudSQL = true;
      console.log("Connected to Google Cloud SQL");
    }
  }

  public isExternalSourceConnected(source: string): boolean {
    return this.externalConnections[source] || false;
  }
  
  public isVectorDatabaseConnected(source: string): boolean {
    return this.vectorConnections[source] || false;
  }

  public getVectorConnectionsStatus(): Record<string, boolean> {
    return { ...this.vectorConnections };
  }

  public getGoogleDatabasesStatus(): Record<string, boolean> {
    return { ...this.googleDbConnections };
  }

  public async searchVideos(query: string): Promise<VideoRecord[]> {
    // Ensure DB is initialized
    if (!this.isInitialized) {
      await this.initializeDatabase();
    }
    
    console.log(`Searching for videos with query: "${query}"`);
    
    const isPromptSearch = query.toLowerCase().includes("prompt") || 
                         query.toLowerCase().includes("ai") || 
                         query.toLowerCase().includes("generate");
    
    // Combine results from local database and external sources
    let results = this.searchLocalDatabase(query);
    
    // If connected to external sources, fetch additional results
    if (this.externalConnections.google || this.externalConnections.openai || this.externalConnections.otherAi) {
      const externalResults = await this.searchExternalSources(query, isPromptSearch);
      results = [...results, ...externalResults];
    }
    
    // If connected to vector databases, fetch semantic search results
    if (this.vectorConnections.cosmosDB || this.vectorConnections.nuclia || this.vectorConnections.vectorDB) {
      const vectorResults = await this.searchVectorDatabases(query, isPromptSearch);
      // Add vector search results, avoiding duplicates
      vectorResults.forEach(vectorResult => {
        if (!results.some(r => r.id === vectorResult.id)) {
          results.push(vectorResult);
        }
      });
    }
    
    // For prompt-oriented searches, prioritize relevant results
    if (isPromptSearch) {
      results = this.prioritizePromptOrientedResults(results, query);
    }
    
    return results;
  }

  private searchLocalDatabase(query: string): VideoRecord[] {
    if (!query.trim()) {
      return this.videos;
    }
    
    const lowerQuery = query.toLowerCase();
    return this.videos.filter(video => 
      video.title.toLowerCase().includes(lowerQuery) || 
      video.description.toLowerCase().includes(lowerQuery) || 
      video.keywords.some(keyword => keyword.toLowerCase().includes(lowerQuery))
    );
  }

  private prioritizePromptOrientedResults(results: VideoRecord[], query: string): VideoRecord[] {
    // First, get exact prompt-oriented matches
    const promptOriented = results.filter(video => video.isPromptOriented === true);
    
    // Then, get remaining results
    const otherResults = results.filter(video => video.isPromptOriented !== true);
    
    // Combine with prompt-oriented results first
    return [...promptOriented, ...otherResults];
  }

  private async searchExternalSources(query: string, isPromptSearch: boolean = false): Promise<VideoRecord[]> {
    console.log(`Searching external sources for: "${query}"`);
    
    const externalResults: VideoRecord[] = [];
    
    // Simulate fetching from Google if connected
    if (this.externalConnections.google) {
      // In a real app, this would be an actual API call
      await new Promise(resolve => setTimeout(resolve, 700));
      
      // Mock Google video results
      if (query.length > 2) {
        externalResults.push({
          id: `google-${Date.now()}-1`,
          title: `Google: ${query.toUpperCase()} Professional Video`,
          description: `High quality ${query} footage sourced from Google's video database`,
          keywords: [query, 'google', 'professional', 'high-quality'],
          thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},video`,
          videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
          duration: "1:15",
          createdAt: new Date().toISOString(),
          source: "google"
        });
        
        if (isPromptSearch) {
          externalResults.push({
            id: `google-${Date.now()}-2`,
            title: `Google: Prompt-Engineered ${query} Video`,
            description: `AI-optimized ${query} footage using advanced prompt engineering`,
            keywords: [query, 'google', 'prompt', 'ai-engineered'],
            thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},ai`,
            videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4",
            duration: "0:55",
            createdAt: new Date().toISOString(),
            source: "google",
            isPromptOriented: true
          });
        }
      }
    }
    
    // Simulate fetching from OpenAI if connected
    if (this.externalConnections.openai) {
      // In a real app, this would be an actual API call
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Mock OpenAI video results
      if (query.length > 1) {
        externalResults.push({
          id: `openai-${Date.now()}-1`,
          title: `AI Generated: ${query} Cinematic Scene`,
          description: `Stunning AI-generated ${query} video with cinematic quality`,
          keywords: [query, 'ai-generated', 'cinematic', 'openai'],
          thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},cinematic`,
          videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
          duration: "0:45",
          createdAt: new Date().toISOString(),
          source: "openai",
          isPromptOriented: isPromptSearch
        });
        
        if (isPromptSearch) {
          externalResults.push({
            id: `openai-${Date.now()}-2`,
            title: `ChatGPT Prompt-Generated: ${query}`,
            description: `Created using ChatGPT's advanced prompt-to-video technology`,
            keywords: [query, 'chatgpt', 'prompt-to-video', 'ai-generated'],
            thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},technology`,
            videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
            duration: "1:05",
            createdAt: new Date().toISOString(),
            source: "openai",
            isPromptOriented: true
          });
        }
      }
    }
    
    // Simulate fetching from Other AI if connected
    if (this.externalConnections.otherAi) {
      // In a real app, this would be an actual API call
      await new Promise(resolve => setTimeout(resolve, 650));
      
      // Mock Other AI video results
      if (query.length > 1) {
        externalResults.push({
          id: `other-ai-${Date.now()}-1`,
          title: `Other AI: ${query} Advanced Scene`,
          description: `Custom AI-generated ${query} video with advanced effects`,
          keywords: [query, 'other-ai', 'advanced', 'custom'],
          thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},tech`,
          videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
          duration: "0:38",
          createdAt: new Date().toISOString(),
          source: "otherAi"
        });
        
        if (isPromptSearch) {
          externalResults.push({
            id: `other-ai-${Date.now()}-2`,
            title: `Prompt-Optimized: ${query} by AI Engine`,
            description: `Fine-tuned prompt engineering for perfect ${query} video generation`,
            keywords: [query, 'prompt-engineering', 'fine-tuned', 'perfect-generation'],
            thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},future`,
            videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
            duration: "0:42",
            createdAt: new Date().toISOString(),
            source: "otherAi",
            isPromptOriented: true
          });
        }
      }
    }
    
    // Add Google database specific results if connected to any Google database
    if (this.googleDbConnections.bigtable || this.googleDbConnections.spanner || 
        this.googleDbConnections.firebase || this.googleDbConnections.cloudSQL) {
      
      // Results from Bigtable
      if (this.googleDbConnections.bigtable) {
        externalResults.push({
          id: `bigtable-${Date.now()}-1`,
          title: `Bigtable: ${query} High-Scale Data`,
          description: `Generated from Google Bigtable's massive ${query} dataset with billions of rows`,
          keywords: [query, 'bigtable', 'high-scale', 'google-database'],
          thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},data`,
          videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
          duration: "0:42",
          createdAt: new Date().toISOString(),
          source: "google",
          dbSource: "bigtable"
        });
      }
      
      // Results from Spanner
      if (this.googleDbConnections.spanner) {
        externalResults.push({
          id: `spanner-${Date.now()}-1`,
          title: `Spanner: ${query} Global Consistency`,
          description: `Globally consistent ${query} data from Google Spanner database`,
          keywords: [query, 'spanner', 'global', 'consistent'],
          thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},global`,
          videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
          duration: "0:51",
          createdAt: new Date().toISOString(),
          source: "google",
          dbSource: "spanner"
        });
      }
      
      // Results from Firebase
      if (this.googleDbConnections.firebase) {
        externalResults.push({
          id: `firebase-${Date.now()}-1`,
          title: `Firebase: Real-time ${query} Update`,
          description: `Real-time updating ${query} content from Firebase database`,
          keywords: [query, 'firebase', 'realtime', 'sync'],
          thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},realtime`,
          videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
          duration: "0:38",
          createdAt: new Date().toISOString(),
          source: "google",
          dbSource: "firebase"
        });
      }
      
      // Results from Cloud SQL
      if (this.googleDbConnections.cloudSQL) {
        externalResults.push({
          id: `cloudsql-${Date.now()}-1`,
          title: `CloudSQL: ${query} Relational Data`,
          description: `Structured ${query} content from Google Cloud SQL database`,
          keywords: [query, 'cloudsql', 'relational', 'structured'],
          thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},database`,
          videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
          duration: "0:44",
          createdAt: new Date().toISOString(),
          source: "google",
          dbSource: "cloudSQL"
        });
      }
    }
    
    return externalResults;
  }
  
  private async searchVectorDatabases(query: string, isPromptSearch: boolean = false): Promise<VideoRecord[]> {
    console.log(`Performing semantic search in vector databases for: "${query}"`);
    
    const vectorResults: VideoRecord[] = [];
    
    // Simulate vector search in Cosmos DB
    if (this.vectorConnections.cosmosDB) {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      if (query.length > 1) {
        vectorResults.push({
          id: `cosmos-${Date.now()}-1`,
          title: `Cosmos DB: Semantic ${query} Match`,
          description: `Vector-matched ${query} content with high semantic relevance`,
          keywords: [query, 'cosmos-db', 'vector-search', 'semantic'],
          thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},database`,
          videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
          duration: "0:58",
          createdAt: new Date().toISOString(),
          source: "cosmosDB",
          vectorMatch: 0.92
        });
        
        if (isPromptSearch) {
          vectorResults.push({
            id: `cosmos-${Date.now()}-2`,
            title: `Cosmos DB: Prompt-Engineered ${query}`,
            description: `Vector-matched ${query} with prompt engineering techniques`,
            keywords: [query, 'cosmos-db', 'vector-match', 'prompt-engineering'],
            thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},vector`,
            videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
            duration: "1:12",
            createdAt: new Date().toISOString(),
            source: "cosmosDB",
            isPromptOriented: true,
            vectorMatch: 0.95
          });
        }
      }
    }
    
    // Simulate vector search in Nuclia
    if (this.vectorConnections.nuclia) {
      await new Promise(resolve => setTimeout(resolve, 750));
      
      if (query.length > 1) {
        vectorResults.push({
          id: `nuclia-${Date.now()}-1`,
          title: `Nuclia KB: ${query} Understanding`,
          description: `Nuclia knowledge-enhanced ${query} content with context understanding`,
          keywords: [query, 'nuclia', 'knowledge-box', 'understanding'],
          thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},knowledge`,
          videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
          duration: "1:05",
          createdAt: new Date().toISOString(),
          source: "nuclia",
          vectorMatch: 0.89
        });
        
        if (isPromptSearch) {
          vectorResults.push({
            id: `nuclia-${Date.now()}-2`,
            title: `Nuclia: Advanced ${query} Prompt Analysis`,
            description: `Knowledge-driven ${query} prompt analysis for video generation`,
            keywords: [query, 'nuclia', 'prompt-analysis', 'knowledge-driven'],
            thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},analysis`,
            videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
            duration: "0:47",
            createdAt: new Date().toISOString(),
            source: "nuclia",
            isPromptOriented: true,
            vectorMatch: 0.96
          });
        }
      }
    }
    
    // Simulate vector search in generic Vector DB
    if (this.vectorConnections.vectorDB) {
      await new Promise(resolve => setTimeout(resolve, 850));
      
      if (query.length > 1) {
        vectorResults.push({
          id: `vector-${Date.now()}-1`,
          title: `VectorDB: Similar ${query} Content`,
          description: `Embedding-based ${query} content with high similarity score`,
          keywords: [query, 'vector-db', 'embedding', 'similarity'],
          thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},similar`,
          videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
          duration: "0:52",
          createdAt: new Date().toISOString(),
          source: "vectorDB",
          vectorMatch: 0.88
        });
        
        if (isPromptSearch) {
          vectorResults.push({
            id: `vector-${Date.now()}-2`,
            title: `VectorDB: ${query} Prompt Optimization`,
            description: `Vector-optimized ${query} prompts for maximum relevance`,
            keywords: [query, 'vector-db', 'prompt-optimization', 'relevance'],
            thumbnailUrl: `https://source.unsplash.com/random/800x450?${query},optimize`,
            videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4",
            duration: "1:02",
            createdAt: new Date().toISOString(),
            source: "vectorDB",
            isPromptOriented: true,
            vectorMatch: 0.94
          });
        }
      }
    }
    
    return vectorResults;
  }

  public async saveGeneratedVideo(videoData: Omit<VideoRecord, 'id' | 'createdAt'>): Promise<VideoRecord> {
    // Ensure DB is initialized
    if (!this.isInitialized) {
      await this.initializeDatabase();
    }
    
    console.log("Saving generated video to database");
    
    // In a real app, this would be an INSERT SQL query
    // INSERT INTO videos (title, description, keywords, thumbnailUrl, videoUrl, duration) VALUES (...)
    
    const newVideo: VideoRecord = {
      id: `v${this.videos.length + 1}`,
      ...videoData,
      createdAt: new Date().toISOString()
    };
    
    this.videos.push(newVideo);
    return newVideo;
  }
  
  public async getRecentVideos(limit: number = 5): Promise<VideoRecord[]> {
    // Ensure DB is initialized
    if (!this.isInitialized) {
      await this.initializeDatabase();
    }
    
    console.log(`Getting ${limit} recent videos`);
    
    // In a real app, this would be a SELECT query with ORDER BY and LIMIT
    // SELECT * FROM videos ORDER BY createdAt DESC LIMIT limit
    
    return [...this.videos]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }

  public getExternalConnectionsStatus(): Record<string, boolean> {
    return { ...this.externalConnections };
  }
}

// Define types for database records
export interface VideoRecord {
  id: string;
  title: string;
  description: string;
  keywords: string[];
  thumbnailUrl: string;
  videoUrl: string;
  duration: string;
  createdAt: string;
  source?: string;  // Added to track where the video comes from
  isPromptOriented?: boolean; // Indicates if this video is focused on prompt engineering
  vectorMatch?: number; // Similarity score for vector database results (0-1)
  dbSource?: string; // Added to track specific database source (bigtable, spanner, firebase, etc.)
}

export default DatabaseService.getInstance();
